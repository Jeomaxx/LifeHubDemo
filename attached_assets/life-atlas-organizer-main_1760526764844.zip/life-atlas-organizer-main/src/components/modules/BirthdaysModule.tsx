
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Gift, Calendar } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

const BirthdaysModule = () => {
  const [birthdays, setBirthdays] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    birthday: '',
    gift_ideas: ''
  });
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      fetchBirthdays();
    }
  }, [user]);

  const fetchBirthdays = async () => {
    try {
      const { data, error } = await supabase
        .from('birthdays')
        .select('*')
        .eq('user_id', user.id)
        .order('birthday', { ascending: true });

      if (error) throw error;
      setBirthdays(data || []);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch birthdays",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { error } = await supabase
        .from('birthdays')
        .insert([{
          ...formData,
          user_id: user.id
        }]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Birthday added successfully",
      });

      setFormData({
        name: '',
        birthday: '',
        gift_ideas: ''
      });
      setShowForm(false);
      fetchBirthdays();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add birthday",
        variant: "destructive",
      });
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Birthday & Gift Tracker</h2>
          <p className="text-slate-600">Remember important dates and gift ideas</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Add Birthday
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Add Birthday</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                placeholder="Name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                required
              />
              <Input
                type="date"
                value={formData.birthday}
                onChange={(e) => setFormData({...formData, birthday: e.target.value})}
                required
              />
              <Textarea
                placeholder="Gift ideas"
                value={formData.gift_ideas}
                onChange={(e) => setFormData({...formData, gift_ideas: e.target.value})}
              />
              <Button type="submit">Add Birthday</Button>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {birthdays.map((birthday) => (
          <Card key={birthday.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="text-lg">{birthday.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <span>{new Date(birthday.birthday).toLocaleDateString()}</span>
                </div>
                {birthday.gift_ideas && (
                  <div className="flex items-start gap-2 text-sm">
                    <Gift className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>{birthday.gift_ideas}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default BirthdaysModule;
