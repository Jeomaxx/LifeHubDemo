
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Plus, Upload, Calendar, DollarSign, TrendingUp, TrendingDown, Filter } from 'lucide-react';

interface FinanceEntry {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  category: string;
  description: string;
  date: string;
  proof?: string;
  verified: boolean;
}

const FinanceModule = () => {
  const [entries, setEntries] = useState<FinanceEntry[]>([
    {
      id: '1',
      type: 'expense',
      amount: 45.50,
      category: 'Food & Dining',
      description: 'Lunch at downtown cafe',
      date: '2024-06-03',
      proof: 'receipt_lunch.jpg',
      verified: true
    },
    {
      id: '2',
      type: 'income',
      amount: 2500.00,
      category: 'Salary',
      description: 'Monthly salary payment',
      date: '2024-06-01',
      proof: 'payslip_june.pdf',
      verified: true
    },
    {
      id: '3',
      type: 'expense',
      amount: 120.00,
      category: 'Transportation',
      description: 'Gas station fill-up',
      date: '2024-06-02',
      verified: false
    }
  ]);

  const [isAddingEntry, setIsAddingEntry] = useState(false);
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const categories = [
    'Food & Dining', 'Transportation', 'Shopping', 'Entertainment',
    'Bills & Utilities', 'Healthcare', 'Education', 'Salary',
    'Freelance', 'Investment', 'Other'
  ];

  const filteredEntries = entries.filter(entry => {
    const typeMatch = filterType === 'all' || entry.type === filterType;
    const categoryMatch = filterCategory === 'all' || entry.category === filterCategory;
    return typeMatch && categoryMatch;
  });

  const totalIncome = entries.filter(e => e.type === 'income').reduce((sum, e) => sum + e.amount, 0);
  const totalExpenses = entries.filter(e => e.type === 'expense').reduce((sum, e) => sum + e.amount, 0);
  const netAmount = totalIncome - totalExpenses;

  const handleAddEntry = (formData: FormData) => {
    const newEntry: FinanceEntry = {
      id: Date.now().toString(),
      type: formData.get('type') as 'income' | 'expense',
      amount: parseFloat(formData.get('amount') as string),
      category: formData.get('category') as string,
      description: formData.get('description') as string,
      date: formData.get('date') as string,
      proof: formData.get('proof') ? 'uploaded_file.jpg' : undefined,
      verified: false
    };
    
    setEntries([newEntry, ...entries]);
    setIsAddingEntry(false);
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-600 font-medium">Total Income</p>
                <p className="text-2xl font-bold text-green-700">${totalIncome.toFixed(2)}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-red-50 border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-600 font-medium">Total Expenses</p>
                <p className="text-2xl font-bold text-red-700">${totalExpenses.toFixed(2)}</p>
              </div>
              <TrendingDown className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card className={`${netAmount >= 0 ? 'bg-blue-50 border-blue-200' : 'bg-orange-50 border-orange-200'}`}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className={`text-sm font-medium ${netAmount >= 0 ? 'text-blue-600' : 'text-orange-600'}`}>
                  Net Amount
                </p>
                <p className={`text-2xl font-bold ${netAmount >= 0 ? 'text-blue-700' : 'text-orange-700'}`}>
                  ${netAmount.toFixed(2)}
                </p>
              </div>
              <DollarSign className={`h-8 w-8 ${netAmount >= 0 ? 'text-blue-500' : 'text-orange-500'}`} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="flex gap-2">
          <Select value={filterType} onValueChange={(value: 'all' | 'income' | 'expense') => setFilterType(value)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="income">Income</SelectItem>
              <SelectItem value="expense">Expense</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Dialog open={isAddingEntry} onOpenChange={setIsAddingEntry}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Entry
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add Finance Entry</DialogTitle>
              <DialogDescription>
                Record a new income or expense with optional proof upload.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={(e) => { e.preventDefault(); handleAddEntry(new FormData(e.currentTarget)); }}>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="type">Type</Label>
                  <Select name="type" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="income">Income</SelectItem>
                      <SelectItem value="expense">Expense</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="amount">Amount ($)</Label>
                  <Input name="amount" type="number" step="0.01" placeholder="0.00" required />
                </div>

                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select name="category" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(category => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea name="description" placeholder="Enter description..." required />
                </div>

                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input name="date" type="date" required />
                </div>

                <div>
                  <Label htmlFor="proof">Proof Upload (Optional)</Label>
                  <Input name="proof" type="file" accept="image/*,.pdf" />
                  <p className="text-xs text-slate-500 mt-1">Upload receipt, invoice, or payment proof</p>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="flex-1">Add Entry</Button>
                  <Button type="button" variant="outline" onClick={() => setIsAddingEntry(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Entries List */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-slate-800">Recent Entries ({filteredEntries.length})</h3>
        {filteredEntries.map((entry) => (
          <Card key={entry.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg ${
                    entry.type === 'income' ? 'bg-green-100' : 'bg-red-100'
                  }`}>
                    {entry.type === 'income' ? (
                      <TrendingUp className={`h-5 w-5 text-green-600`} />
                    ) : (
                      <TrendingDown className={`h-5 w-5 text-red-600`} />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium text-slate-800">{entry.description}</h4>
                      {entry.proof && (
                        <Badge variant="secondary" className="text-xs">
                          <Upload className="w-3 h-3 mr-1" />
                          Proof
                        </Badge>
                      )}
                      {entry.verified && (
                        <Badge variant="default" className="text-xs bg-green-600">
                          Verified
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-slate-600">
                      <span>{entry.category}</span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {entry.date}
                      </span>
                    </div>
                  </div>
                </div>
                <div className={`text-xl font-semibold ${
                  entry.type === 'income' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {entry.type === 'income' ? '+' : '-'}${entry.amount.toFixed(2)}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default FinanceModule;
