
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Plus, Upload, Calendar, Target, TrendingUp, Clock } from 'lucide-react';

interface Goal {
  id: string;
  title: string;
  description: string;
  category: string;
  type: 'personal' | 'professional' | 'health' | 'financial';
  targetDate: string;
  progress: number;
  milestones: string[];
  proof?: string;
  status: 'active' | 'completed' | 'paused';
  createdAt: string;
}

const GoalModule = () => {
  const [goals, setGoals] = useState<Goal[]>([
    {
      id: '1',
      title: 'Complete React Certification',
      description: 'Finish the advanced React certification course and pass the final exam',
      category: 'Learning',
      type: 'professional',
      targetDate: '2024-08-15',
      progress: 65,
      milestones: ['Complete basic modules', 'Finish project assignments', 'Take practice tests'],
      status: 'active',
      createdAt: '2024-05-01'
    },
    {
      id: '2',
      title: 'Save $10,000 for Emergency Fund',
      description: 'Build an emergency fund with 6 months of living expenses',
      category: 'Finance',
      type: 'financial',
      targetDate: '2024-12-31',
      progress: 40,
      milestones: ['Save first $2,500', 'Reach $5,000 milestone', 'Hit $7,500 target'],
      proof: 'savings_statement.pdf',
      status: 'active',
      createdAt: '2024-01-01'
    },
    {
      id: '3',
      title: 'Run Half Marathon',
      description: 'Complete a 21K half marathon race in under 2 hours',
      category: 'Fitness',
      type: 'health',
      targetDate: '2024-09-22',
      progress: 30,
      milestones: ['Run 5K consistently', 'Complete 10K race', 'Build to 15K distance'],
      status: 'active',
      createdAt: '2024-04-15'
    }
  ]);

  const [isAddingGoal, setIsAddingGoal] = useState(false);
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const categories = ['Learning', 'Finance', 'Fitness', 'Career', 'Health', 'Personal', 'Business', 'Other'];

  const filteredGoals = goals.filter(goal => {
    const typeMatch = filterType === 'all' || goal.type === filterType;
    const statusMatch = filterStatus === 'all' || goal.status === filterStatus;
    return typeMatch && statusMatch;
  });

  const goalStats = {
    total: goals.length,
    active: goals.filter(g => g.status === 'active').length,
    completed: goals.filter(g => g.status === 'completed').length,
    avgProgress: Math.round(goals.reduce((sum, g) => sum + g.progress, 0) / goals.length)
  };

  const handleAddGoal = (formData: FormData) => {
    const newGoal: Goal = {
      id: Date.now().toString(),
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      category: formData.get('category') as string,
      type: formData.get('type') as Goal['type'],
      targetDate: formData.get('targetDate') as string,
      progress: 0,
      milestones: (formData.get('milestones') as string).split('\n').filter(m => m.trim()),
      proof: formData.get('proof') ? 'uploaded_file.pdf' : undefined,
      status: 'active',
      createdAt: new Date().toISOString().split('T')[0]
    };
    
    setGoals([newGoal, ...goals]);
    setIsAddingGoal(false);
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'professional': return 'bg-blue-100 text-blue-800';
      case 'personal': return 'bg-purple-100 text-purple-800';
      case 'health': return 'bg-green-100 text-green-800';
      case 'financial': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-700">{goalStats.total}</p>
              <p className="text-sm text-blue-600">Total Goals</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-700">{goalStats.active}</p>
              <p className="text-sm text-green-600">Active Goals</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-purple-50 border-purple-200">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-700">{goalStats.completed}</p>
              <p className="text-sm text-purple-600">Completed</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-orange-50 border-orange-200">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-700">{goalStats.avgProgress}%</p>
              <p className="text-sm text-orange-600">Avg Progress</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="flex gap-2">
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="personal">Personal</SelectItem>
              <SelectItem value="professional">Professional</SelectItem>
              <SelectItem value="health">Health</SelectItem>
              <SelectItem value="financial">Financial</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="paused">Paused</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Dialog open={isAddingGoal} onOpenChange={setIsAddingGoal}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Goal
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Goal</DialogTitle>
              <DialogDescription>
                Create a SMART goal with milestones and optional proof tracking.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={(e) => { e.preventDefault(); handleAddGoal(new FormData(e.currentTarget)); }}>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Goal Title</Label>
                  <Input name="title" placeholder="Enter goal title..." required />
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea name="description" placeholder="Describe your goal..." required />
                </div>

                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select name="category" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(category => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="type">Type</Label>
                  <Select name="type" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="personal">Personal</SelectItem>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="health">Health</SelectItem>
                      <SelectItem value="financial">Financial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="targetDate">Target Date</Label>
                  <Input name="targetDate" type="date" required />
                </div>

                <div>
                  <Label htmlFor="milestones">Milestones (one per line)</Label>
                  <Textarea name="milestones" placeholder="List your milestones..." />
                </div>

                <div>
                  <Label htmlFor="proof">Proof Upload (Optional)</Label>
                  <Input name="proof" type="file" accept="image/*,.pdf" />
                  <p className="text-xs text-slate-500 mt-1">Upload supporting documents or progress proof</p>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="flex-1">Add Goal</Button>
                  <Button type="button" variant="outline" onClick={() => setIsAddingGoal(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Goals List */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-slate-800">Goals ({filteredGoals.length})</h3>
        {filteredGoals.map((goal) => (
          <Card key={goal.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <Target className="h-5 w-5 text-blue-600" />
                      <h4 className="text-lg font-semibold text-slate-800">{goal.title}</h4>
                      {goal.proof && (
                        <Badge variant="secondary" className="text-xs">
                          <Upload className="w-3 h-3 mr-1" />
                          Proof
                        </Badge>
                      )}
                    </div>
                    <p className="text-slate-600 mb-3">{goal.description}</p>
                    
                    <div className="flex items-center gap-4 mb-4">
                      <Badge className={getTypeColor(goal.type)}>
                        {goal.type}
                      </Badge>
                      <span className="text-sm text-slate-500">{goal.category}</span>
                      <span className="flex items-center gap-1 text-sm text-slate-500">
                        <Calendar className="w-3 h-3" />
                        Due: {goal.targetDate}
                      </span>
                    </div>
                  </div>
                  <Badge variant={goal.status === 'active' ? 'default' : 'secondary'}>
                    {goal.status}
                  </Badge>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-slate-700">Progress</span>
                    <span className="text-sm text-slate-600">{goal.progress}%</span>
                  </div>
                  <Progress value={goal.progress} className="h-2" />
                </div>

                {goal.milestones.length > 0 && (
                  <div>
                    <h5 className="text-sm font-medium text-slate-700 mb-2">Milestones:</h5>
                    <ul className="text-sm text-slate-600 space-y-1">
                      {goal.milestones.map((milestone, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
                          {milestone}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default GoalModule;
