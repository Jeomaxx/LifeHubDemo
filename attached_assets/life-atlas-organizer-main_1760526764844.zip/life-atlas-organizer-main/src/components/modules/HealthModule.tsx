
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Plus, Upload, Calendar, Heart, Activity, Scale, Droplets } from 'lucide-react';

interface HealthEntry {
  id: string;
  type: 'workout' | 'nutrition' | 'weight' | 'hydration' | 'sleep';
  title: string;
  description: string;
  category: string;
  value?: number;
  unit?: string;
  date: string;
  proof?: string;
  createdAt: string;
}

const HealthModule = () => {
  const [entries, setEntries] = useState<HealthEntry[]>([
    {
      id: '1',
      type: 'workout',
      title: 'Morning Cardio Session',
      description: '30 minutes treadmill run with interval training',
      category: 'Cardio',
      value: 30,
      unit: 'minutes',
      date: '2024-06-03',
      proof: 'workout_selfie.jpg',
      createdAt: '2024-06-03'
    },
    {
      id: '2',
      type: 'weight',
      title: 'Weekly Weigh-in',
      description: 'Regular morning weight check',
      category: 'Weight Tracking',
      value: 75.2,
      unit: 'kg',
      date: '2024-06-03',
      createdAt: '2024-06-03'
    },
    {
      id: '3',
      type: 'nutrition',
      title: 'Healthy Breakfast',
      description: 'Oatmeal with berries and nuts - 350 calories',
      category: 'Breakfast',
      value: 350,
      unit: 'calories',
      date: '2024-06-03',
      proof: 'breakfast_photo.jpg',
      createdAt: '2024-06-03'
    },
    {
      id: '4',
      type: 'hydration',
      title: 'Daily Water Intake',
      description: 'Tracking water consumption throughout the day',
      category: 'Hydration',
      value: 2.5,
      unit: 'liters',
      date: '2024-06-03',
      createdAt: '2024-06-03'
    }
  ]);

  const [isAddingEntry, setIsAddingEntry] = useState(false);
  const [filterType, setFilterType] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const categories = {
    workout: ['Cardio', 'Strength', 'Yoga', 'Sports', 'Walking', 'Other'],
    nutrition: ['Breakfast', 'Lunch', 'Dinner', 'Snacks', 'Supplements'],
    weight: ['Weight Tracking'],
    hydration: ['Hydration'],
    sleep: ['Sleep Tracking']
  };

  const filteredEntries = entries.filter(entry => {
    const typeMatch = filterType === 'all' || entry.type === filterType;
    const categoryMatch = filterCategory === 'all' || entry.category === filterCategory;
    return typeMatch && categoryMatch;
  });

  const todayStats = {
    workouts: entries.filter(e => e.type === 'workout' && e.date === '2024-06-03').length,
    calories: entries.filter(e => e.type === 'nutrition' && e.date === '2024-06-03')
      .reduce((sum, e) => sum + (e.value || 0), 0),
    water: entries.find(e => e.type === 'hydration' && e.date === '2024-06-03')?.value || 0,
    currentWeight: entries.filter(e => e.type === 'weight').sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime())[0]?.value || 0
  };

  const handleAddEntry = (formData: FormData) => {
    const entryType = formData.get('type') as HealthEntry['type'];
    const newEntry: HealthEntry = {
      id: Date.now().toString(),
      type: entryType,
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      category: formData.get('category') as string,
      value: formData.get('value') ? parseFloat(formData.get('value') as string) : undefined,
      unit: formData.get('unit') as string || undefined,
      date: formData.get('date') as string,
      proof: formData.get('proof') ? 'uploaded_file.jpg' : undefined,
      createdAt: new Date().toISOString().split('T')[0]
    };
    
    setEntries([newEntry, ...entries]);
    setIsAddingEntry(false);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'workout': return <Activity className="h-5 w-5 text-blue-600" />;
      case 'nutrition': return <Heart className="h-5 w-5 text-green-600" />;
      case 'weight': return <Scale className="h-5 w-5 text-purple-600" />;
      case 'hydration': return <Droplets className="h-5 w-5 text-cyan-600" />;
      case 'sleep': return <Calendar className="h-5 w-5 text-indigo-600" />;
      default: return <Heart className="h-5 w-5 text-gray-600" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'workout': return 'bg-blue-100 text-blue-800';
      case 'nutrition': return 'bg-green-100 text-green-800';
      case 'weight': return 'bg-purple-100 text-purple-800';
      case 'hydration': return 'bg-cyan-100 text-cyan-800';
      case 'sleep': return 'bg-indigo-100 text-indigo-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-600 font-medium">Today's Workouts</p>
                <p className="text-2xl font-bold text-blue-700">{todayStats.workouts}</p>
              </div>
              <Activity className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-600 font-medium">Calories Today</p>
                <p className="text-2xl font-bold text-green-700">{todayStats.calories}</p>
              </div>
              <Heart className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-cyan-50 border-cyan-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-cyan-600 font-medium">Water (Liters)</p>
                <p className="text-2xl font-bold text-cyan-700">{todayStats.water}</p>
              </div>
              <Droplets className="h-8 w-8 text-cyan-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-purple-50 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-600 font-medium">Current Weight</p>
                <p className="text-2xl font-bold text-purple-700">{todayStats.currentWeight} kg</p>
              </div>
              <Scale className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="flex gap-2">
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="workout">Workout</SelectItem>
              <SelectItem value="nutrition">Nutrition</SelectItem>
              <SelectItem value="weight">Weight</SelectItem>
              <SelectItem value="hydration">Hydration</SelectItem>
              <SelectItem value="sleep">Sleep</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {Object.values(categories).flat().map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Dialog open={isAddingEntry} onOpenChange={setIsAddingEntry}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Entry
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add Health Entry</DialogTitle>
              <DialogDescription>
                Track your health and fitness activities with optional proof upload.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={(e) => { e.preventDefault(); handleAddEntry(new FormData(e.currentTarget)); }}>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="type">Type</Label>
                  <Select name="type" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="workout">Workout</SelectItem>
                      <SelectItem value="nutrition">Nutrition</SelectItem>
                      <SelectItem value="weight">Weight</SelectItem>
                      <SelectItem value="hydration">Hydration</SelectItem>
                      <SelectItem value="sleep">Sleep</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input name="title" placeholder="Enter title..." required />
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea name="description" placeholder="Describe your activity..." required />
                </div>

                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select name="category" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.values(categories).flat().map(category => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="value">Value (Optional)</Label>
                    <Input name="value" type="number" step="0.1" placeholder="0" />
                  </div>
                  <div>
                    <Label htmlFor="unit">Unit</Label>
                    <Input name="unit" placeholder="kg, min, cal..." />
                  </div>
                </div>

                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input name="date" type="date" required />
                </div>

                <div>
                  <Label htmlFor="proof">Proof Upload (Optional)</Label>
                  <Input name="proof" type="file" accept="image/*,.pdf" />
                  <p className="text-xs text-slate-500 mt-1">Upload photos or documents as proof</p>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="flex-1">Add Entry</Button>
                  <Button type="button" variant="outline" onClick={() => setIsAddingEntry(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Entries List */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-slate-800">Health Entries ({filteredEntries.length})</h3>
        {filteredEntries.map((entry) => (
          <Card key={entry.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-2 bg-gray-100 rounded-lg">
                    {getTypeIcon(entry.type)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium text-slate-800">{entry.title}</h4>
                      {entry.proof && (
                        <Badge variant="secondary" className="text-xs">
                          <Upload className="w-3 h-3 mr-1" />
                          Proof
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-slate-600 mb-2">{entry.description}</p>
                    <div className="flex items-center gap-4 text-sm text-slate-500">
                      <Badge className={getTypeColor(entry.type)}>
                        {entry.type}
                      </Badge>
                      <span>{entry.category}</span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {entry.date}
                      </span>
                    </div>
                  </div>
                </div>
                {entry.value && (
                  <div className="text-right">
                    <p className="text-lg font-semibold text-slate-800">
                      {entry.value} {entry.unit}
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default HealthModule;
