
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';

const InvestmentModule = () => {
  const [investments] = useState([
    {
      id: 1,
      symbol: 'AAPL',
      type: 'buy',
      quantity: 10,
      price: 150.25,
      totalValue: 1502.50,
      date: '2024-01-15',
      currentPrice: 175.30
    },
    {
      id: 2,
      symbol: 'TSLA',
      type: 'buy',
      quantity: 5,
      price: 200.00,
      totalValue: 1000.00,
      date: '2024-01-20',
      currentPrice: 185.50
    }
  ]);

  const totalInvested = investments.reduce((sum, inv) => sum + inv.totalValue, 0);
  const currentValue = investments.reduce((sum, inv) => sum + (inv.quantity * inv.currentPrice), 0);
  const totalGainLoss = currentValue - totalInvested;
  const gainLossPercentage = ((totalGainLoss / totalInvested) * 100).toFixed(2);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Investment Tracker</h2>
          <p className="text-slate-600">Monitor your investment portfolio</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Add Investment
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Invested</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalInvested.toFixed(2)}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Current Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${currentValue.toFixed(2)}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Gain/Loss</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${totalGainLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              ${totalGainLoss.toFixed(2)}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Return %</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${totalGainLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {gainLossPercentage}%
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {investments.map((investment) => {
          const currentValue = investment.quantity * investment.currentPrice;
          const gainLoss = currentValue - investment.totalValue;
          const gainLossPercent = ((gainLoss / investment.totalValue) * 100).toFixed(2);
          
          return (
            <Card key={investment.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{investment.symbol}</CardTitle>
                  <Badge variant={investment.type === 'buy' ? 'default' : 'secondary'}>
                    {investment.type.toUpperCase()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Quantity:</span>
                    <span className="font-semibold">{investment.quantity}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Avg Price:</span>
                    <span className="font-semibold">${investment.price}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Current Price:</span>
                    <span className="font-semibold">${investment.currentPrice}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Invested:</span>
                    <span className="font-semibold">${investment.totalValue}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Current Value:</span>
                    <span className="font-semibold">${currentValue.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Gain/Loss:</span>
                    <div className={`flex items-center gap-1 ${gainLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {gainLoss >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                      <span className="font-semibold text-sm">${gainLoss.toFixed(2)} ({gainLossPercent}%)</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default InvestmentModule;
