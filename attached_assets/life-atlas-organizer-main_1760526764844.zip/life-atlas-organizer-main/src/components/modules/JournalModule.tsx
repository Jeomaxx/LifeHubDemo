
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Plus, Upload, Calendar, BookOpen, Smile, Meh, Frown, Heart, Star } from 'lucide-react';

interface JournalEntry {
  id: string;
  title: string;
  content: string;
  mood: 'excellent' | 'good' | 'neutral' | 'poor' | 'terrible';
  category: string;
  tags: string[];
  date: string;
  proof?: string;
  createdAt: string;
}

const JournalModule = () => {
  const [entries, setEntries] = useState<JournalEntry[]>([
    {
      id: '1',
      title: 'Productive Monday',
      content: 'Started the week with great energy. Completed the morning workout and tackled several important tasks. Feeling optimistic about the week ahead. The new routine is really helping with my productivity and mental clarity.',
      mood: 'excellent',
      category: 'Work & Productivity',
      tags: ['productivity', 'workout', 'motivation'],
      date: '2024-06-03',
      createdAt: '2024-06-03'
    },
    {
      id: '2',
      title: 'Family Time',
      content: 'Had a wonderful dinner with family. We cooked together and shared stories about our day. These moments remind me of what truly matters in life. Grateful for having such supportive people around me.',
      mood: 'good',
      category: 'Personal & Family',
      tags: ['family', 'gratitude', 'cooking'],
      date: '2024-06-02',
      proof: 'family_dinner.jpg',
      createdAt: '2024-06-02'
    },
    {
      id: '3',
      title: 'Challenging Day',
      content: 'Work was particularly stressful today with multiple deadlines. Feeling a bit overwhelmed but trying to stay positive. Need to work on better time management and maybe take more breaks.',
      mood: 'neutral',
      category: 'Work & Productivity',
      tags: ['stress', 'deadlines', 'reflection'],
      date: '2024-06-01',
      createdAt: '2024-06-01'
    }
  ]);

  const [isAddingEntry, setIsAddingEntry] = useState(false);
  const [filterMood, setFilterMood] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const categories = [
    'Work & Productivity', 'Personal & Family', 'Health & Fitness', 
    'Travel & Adventures', 'Learning & Growth', 'Relationships', 
    'Hobbies & Interests', 'Reflection & Gratitude', 'Other'
  ];

  const moodOptions = [
    { value: 'excellent', label: 'Excellent', icon: Star, color: 'text-yellow-500' },
    { value: 'good', label: 'Good', icon: Smile, color: 'text-green-500' },
    { value: 'neutral', label: 'Neutral', icon: Meh, color: 'text-gray-500' },
    { value: 'poor', label: 'Poor', icon: Frown, color: 'text-orange-500' },
    { value: 'terrible', label: 'Terrible', icon: Heart, color: 'text-red-500' }
  ];

  const filteredEntries = entries.filter(entry => {
    const moodMatch = filterMood === 'all' || entry.mood === filterMood;
    const categoryMatch = filterCategory === 'all' || entry.category === filterCategory;
    return moodMatch && categoryMatch;
  });

  const moodStats = {
    excellent: entries.filter(e => e.mood === 'excellent').length,
    good: entries.filter(e => e.mood === 'good').length,
    neutral: entries.filter(e => e.mood === 'neutral').length,
    poor: entries.filter(e => e.mood === 'poor').length,
    terrible: entries.filter(e => e.mood === 'terrible').length
  };

  const handleAddEntry = (formData: FormData) => {
    const tagsString = formData.get('tags') as string;
    const newEntry: JournalEntry = {
      id: Date.now().toString(),
      title: formData.get('title') as string,
      content: formData.get('content') as string,
      mood: formData.get('mood') as JournalEntry['mood'],
      category: formData.get('category') as string,
      tags: tagsString ? tagsString.split(',').map(tag => tag.trim()) : [],
      date: formData.get('date') as string,
      proof: formData.get('proof') ? 'uploaded_file.jpg' : undefined,
      createdAt: new Date().toISOString().split('T')[0]
    };
    
    setEntries([newEntry, ...entries]);
    setIsAddingEntry(false);
  };

  const getMoodIcon = (mood: string) => {
    const moodOption = moodOptions.find(m => m.value === mood);
    if (moodOption) {
      const IconComponent = moodOption.icon;
      return <IconComponent className={`h-5 w-5 ${moodOption.color}`} />;
    }
    return <Meh className="h-5 w-5 text-gray-500" />;
  };

  const getMoodColor = (mood: string) => {
    switch (mood) {
      case 'excellent': return 'bg-yellow-100 text-yellow-800';
      case 'good': return 'bg-green-100 text-green-800';
      case 'neutral': return 'bg-gray-100 text-gray-800';
      case 'poor': return 'bg-orange-100 text-orange-800';
      case 'terrible': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Mood Summary */}
      <div className="grid grid-cols-5 gap-2">
        {moodOptions.map(mood => (
          <Card key={mood.value} className="hover:shadow-md transition-shadow">
            <CardContent className="p-3">
              <div className="text-center">
                <div className="flex justify-center mb-1">
                  <mood.icon className={`h-6 w-6 ${mood.color}`} />
                </div>
                <p className="text-lg font-bold text-slate-800">
                  {moodStats[mood.value as keyof typeof moodStats]}
                </p>
                <p className="text-xs text-slate-600">{mood.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="flex gap-2">
          <Select value={filterMood} onValueChange={setFilterMood}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Moods</SelectItem>
              {moodOptions.map(mood => (
                <SelectItem key={mood.value} value={mood.value}>{mood.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Dialog open={isAddingEntry} onOpenChange={setIsAddingEntry}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Entry
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add Journal Entry</DialogTitle>
              <DialogDescription>
                Record your thoughts, experiences, and mood with optional images.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={(e) => { e.preventDefault(); handleAddEntry(new FormData(e.currentTarget)); }}>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input name="title" placeholder="Entry title..." required />
                </div>

                <div>
                  <Label htmlFor="content">Content</Label>
                  <Textarea 
                    name="content" 
                    placeholder="Write about your day, thoughts, experiences..." 
                    className="min-h-[120px]"
                    required 
                  />
                </div>

                <div>
                  <Label htmlFor="mood">Mood</Label>
                  <Select name="mood" required>
                    <SelectTrigger>
                      <SelectValue placeholder="How are you feeling?" />
                    </SelectTrigger>
                    <SelectContent>
                      {moodOptions.map(mood => (
                        <SelectItem key={mood.value} value={mood.value}>
                          <div className="flex items-center gap-2">
                            <mood.icon className={`h-4 w-4 ${mood.color}`} />
                            {mood.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select name="category" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(category => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="tags">Tags (comma separated)</Label>
                  <Input name="tags" placeholder="mood, family, work..." />
                </div>

                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input name="date" type="date" required />
                </div>

                <div>
                  <Label htmlFor="proof">Image Upload (Optional)</Label>
                  <Input name="proof" type="file" accept="image/*" />
                  <p className="text-xs text-slate-500 mt-1">Add photos to accompany your entry</p>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="flex-1">Add Entry</Button>
                  <Button type="button" variant="outline" onClick={() => setIsAddingEntry(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Entries List */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-slate-800">Journal Entries ({filteredEntries.length})</h3>
        {filteredEntries.map((entry) => (
          <Card key={entry.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <BookOpen className="h-5 w-5 text-slate-600" />
                    <h4 className="text-lg font-semibold text-slate-800">{entry.title}</h4>
                    {entry.proof && (
                      <Badge variant="secondary" className="text-xs">
                        <Upload className="w-3 h-3 mr-1" />
                        Image
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {getMoodIcon(entry.mood)}
                    <Badge className={getMoodColor(entry.mood)}>
                      {entry.mood}
                    </Badge>
                  </div>
                </div>

                <p className="text-slate-700 leading-relaxed">{entry.content}</p>

                <div className="flex items-center justify-between pt-2">
                  <div className="flex items-center gap-4 text-sm text-slate-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {entry.date}
                    </span>
                    <span>{entry.category}</span>
                  </div>

                  {entry.tags.length > 0 && (
                    <div className="flex gap-1">
                      {entry.tags.map(tag => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default JournalModule;
