export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      assets: {
        Row: {
          category_id: string | null
          created_at: string | null
          description: string | null
          estimated_value: number | null
          id: string
          name: string
          proof_url: string | null
          purchase_date: string | null
          user_id: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          estimated_value?: number | null
          id?: string
          name: string
          proof_url?: string | null
          purchase_date?: string | null
          user_id: string
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          estimated_value?: number | null
          id?: string
          name?: string
          proof_url?: string | null
          purchase_date?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "assets_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      bills: {
        Row: {
          amount: number
          category_id: string | null
          created_at: string | null
          due_date: string
          id: string
          name: string
          proof_url: string | null
          status: string | null
          user_id: string
        }
        Insert: {
          amount: number
          category_id?: string | null
          created_at?: string | null
          due_date: string
          id?: string
          name: string
          proof_url?: string | null
          status?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          category_id?: string | null
          created_at?: string | null
          due_date?: string
          id?: string
          name?: string
          proof_url?: string | null
          status?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bills_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      birthdays: {
        Row: {
          birthday: string
          category_id: string | null
          created_at: string | null
          gift_ideas: string | null
          id: string
          name: string
          proof_url: string | null
          user_id: string
        }
        Insert: {
          birthday: string
          category_id?: string | null
          created_at?: string | null
          gift_ideas?: string | null
          id?: string
          name: string
          proof_url?: string | null
          user_id: string
        }
        Update: {
          birthday?: string
          category_id?: string | null
          created_at?: string | null
          gift_ideas?: string | null
          id?: string
          name?: string
          proof_url?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "birthdays_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      categories: {
        Row: {
          color: string | null
          created_at: string | null
          id: string
          module_type: string
          name: string
          user_id: string
        }
        Insert: {
          color?: string | null
          created_at?: string | null
          id?: string
          module_type: string
          name: string
          user_id: string
        }
        Update: {
          color?: string | null
          created_at?: string | null
          id?: string
          module_type?: string
          name?: string
          user_id?: string
        }
        Relationships: []
      }
      contacts: {
        Row: {
          category_id: string | null
          company: string | null
          created_at: string | null
          email: string | null
          id: string
          name: string
          notes: string | null
          phone: string | null
          proof_url: string | null
          role: string | null
          user_id: string
        }
        Insert: {
          category_id?: string | null
          company?: string | null
          created_at?: string | null
          email?: string | null
          id?: string
          name: string
          notes?: string | null
          phone?: string | null
          proof_url?: string | null
          role?: string | null
          user_id: string
        }
        Update: {
          category_id?: string | null
          company?: string | null
          created_at?: string | null
          email?: string | null
          id?: string
          name?: string
          notes?: string | null
          phone?: string | null
          proof_url?: string | null
          role?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "contacts_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      contracts: {
        Row: {
          category_id: string | null
          created_at: string | null
          description: string | null
          document_url: string
          end_date: string | null
          id: string
          start_date: string
          status: string | null
          title: string
          user_id: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          document_url: string
          end_date?: string | null
          id?: string
          start_date: string
          status?: string | null
          title: string
          user_id: string
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          document_url?: string
          end_date?: string | null
          id?: string
          start_date?: string
          status?: string | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "contracts_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          budget: number | null
          category_id: string | null
          created_at: string | null
          description: string | null
          event_date: string
          id: string
          proof_url: string | null
          spent: number | null
          status: string | null
          title: string
          user_id: string
        }
        Insert: {
          budget?: number | null
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          event_date: string
          id?: string
          proof_url?: string | null
          spent?: number | null
          status?: string | null
          title: string
          user_id: string
        }
        Update: {
          budget?: number | null
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          event_date?: string
          id?: string
          proof_url?: string | null
          spent?: number | null
          status?: string | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "events_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      finance_entries: {
        Row: {
          amount: number
          category_id: string | null
          created_at: string | null
          date: string | null
          description: string
          id: string
          proof_url: string | null
          type: string
          user_id: string
        }
        Insert: {
          amount: number
          category_id?: string | null
          created_at?: string | null
          date?: string | null
          description: string
          id?: string
          proof_url?: string | null
          type: string
          user_id: string
        }
        Update: {
          amount?: number
          category_id?: string | null
          created_at?: string | null
          date?: string | null
          description?: string
          id?: string
          proof_url?: string | null
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "finance_entries_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      goals: {
        Row: {
          category_id: string | null
          created_at: string | null
          current_value: number | null
          description: string | null
          id: string
          proof_url: string | null
          status: string | null
          target_date: string | null
          target_value: number | null
          title: string
          user_id: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          current_value?: number | null
          description?: string | null
          id?: string
          proof_url?: string | null
          status?: string | null
          target_date?: string | null
          target_value?: number | null
          title: string
          user_id: string
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          current_value?: number | null
          description?: string | null
          id?: string
          proof_url?: string | null
          status?: string | null
          target_date?: string | null
          target_value?: number | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "goals_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      habit_logs: {
        Row: {
          completed: boolean | null
          created_at: string | null
          date: string | null
          habit_id: string
          id: string
          proof_url: string | null
        }
        Insert: {
          completed?: boolean | null
          created_at?: string | null
          date?: string | null
          habit_id: string
          id?: string
          proof_url?: string | null
        }
        Update: {
          completed?: boolean | null
          created_at?: string | null
          date?: string | null
          habit_id?: string
          id?: string
          proof_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "habit_logs_habit_id_fkey"
            columns: ["habit_id"]
            isOneToOne: false
            referencedRelation: "habits"
            referencedColumns: ["id"]
          },
        ]
      }
      habits: {
        Row: {
          best_streak: number | null
          category_id: string | null
          created_at: string | null
          current_streak: number | null
          description: string | null
          frequency: string | null
          id: string
          name: string
          user_id: string
        }
        Insert: {
          best_streak?: number | null
          category_id?: string | null
          created_at?: string | null
          current_streak?: number | null
          description?: string | null
          frequency?: string | null
          id?: string
          name: string
          user_id: string
        }
        Update: {
          best_streak?: number | null
          category_id?: string | null
          created_at?: string | null
          current_streak?: number | null
          description?: string | null
          frequency?: string | null
          id?: string
          name?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "habits_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      health_entries: {
        Row: {
          category_id: string | null
          created_at: string | null
          date: string | null
          id: string
          notes: string | null
          proof_url: string | null
          type: string
          unit: string | null
          user_id: string
          value: number | null
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          date?: string | null
          id?: string
          notes?: string | null
          proof_url?: string | null
          type: string
          unit?: string | null
          user_id: string
          value?: number | null
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          date?: string | null
          id?: string
          notes?: string | null
          proof_url?: string | null
          type?: string
          unit?: string | null
          user_id?: string
          value?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "health_entries_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      hobbies: {
        Row: {
          category_id: string | null
          created_at: string | null
          description: string | null
          id: string
          name: string
          proof_url: string | null
          session_date: string | null
          time_spent: number | null
          user_id: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          name: string
          proof_url?: string | null
          session_date?: string | null
          time_spent?: number | null
          user_id: string
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          name?: string
          proof_url?: string | null
          session_date?: string | null
          time_spent?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "hobbies_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      important_links: {
        Row: {
          category_id: string | null
          created_at: string | null
          description: string | null
          id: string
          proof_url: string | null
          title: string
          url: string
          user_id: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          proof_url?: string | null
          title: string
          url: string
          user_id: string
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          proof_url?: string | null
          title?: string
          url?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "important_links_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      investments: {
        Row: {
          category_id: string | null
          created_at: string | null
          date: string | null
          id: string
          price: number
          proof_url: string | null
          quantity: number
          symbol: string
          total_value: number
          type: string | null
          user_id: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          date?: string | null
          id?: string
          price: number
          proof_url?: string | null
          quantity: number
          symbol: string
          total_value: number
          type?: string | null
          user_id: string
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          date?: string | null
          id?: string
          price?: number
          proof_url?: string | null
          quantity?: number
          symbol?: string
          total_value?: number
          type?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "investments_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      job_applications: {
        Row: {
          application_date: string | null
          category_id: string | null
          company: string
          created_at: string | null
          id: string
          notes: string | null
          position: string
          resume_url: string | null
          status: string | null
          user_id: string
        }
        Insert: {
          application_date?: string | null
          category_id?: string | null
          company: string
          created_at?: string | null
          id?: string
          notes?: string | null
          position: string
          resume_url?: string | null
          status?: string | null
          user_id: string
        }
        Update: {
          application_date?: string | null
          category_id?: string | null
          company?: string
          created_at?: string | null
          id?: string
          notes?: string | null
          position?: string
          resume_url?: string | null
          status?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_applications_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      journal_entries: {
        Row: {
          category_id: string | null
          content: string
          created_at: string | null
          date: string | null
          id: string
          mood: number | null
          proof_url: string | null
          title: string | null
          user_id: string
        }
        Insert: {
          category_id?: string | null
          content: string
          created_at?: string | null
          date?: string | null
          id?: string
          mood?: number | null
          proof_url?: string | null
          title?: string | null
          user_id: string
        }
        Update: {
          category_id?: string | null
          content?: string
          created_at?: string | null
          date?: string | null
          id?: string
          mood?: number | null
          proof_url?: string | null
          title?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "journal_entries_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      learning_resources: {
        Row: {
          author: string | null
          category_id: string | null
          created_at: string | null
          id: string
          progress: number | null
          proof_url: string | null
          status: string | null
          title: string
          type: string | null
          user_id: string
        }
        Insert: {
          author?: string | null
          category_id?: string | null
          created_at?: string | null
          id?: string
          progress?: number | null
          proof_url?: string | null
          status?: string | null
          title: string
          type?: string | null
          user_id: string
        }
        Update: {
          author?: string | null
          category_id?: string | null
          created_at?: string | null
          id?: string
          progress?: number | null
          proof_url?: string | null
          status?: string | null
          title?: string
          type?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "learning_resources_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      media_tracker: {
        Row: {
          category_id: string | null
          created_at: string | null
          id: string
          proof_url: string | null
          rating: number | null
          status: string | null
          title: string
          type: string | null
          user_id: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          id?: string
          proof_url?: string | null
          rating?: number | null
          status?: string | null
          title: string
          type?: string | null
          user_id: string
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          id?: string
          proof_url?: string | null
          rating?: number | null
          status?: string | null
          title?: string
          type?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "media_tracker_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          body: string
          created_at: string | null
          data: Json | null
          id: string
          read: boolean | null
          title: string
          user_id: string | null
        }
        Insert: {
          body: string
          created_at?: string | null
          data?: Json | null
          id?: string
          read?: boolean | null
          title: string
          user_id?: string | null
        }
        Update: {
          body?: string
          created_at?: string | null
          data?: Json | null
          id?: string
          read?: boolean | null
          title?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_stats"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      posts: {
        Row: {
          content: string | null
          created_at: string | null
          id: string
          image_url: string | null
          likes_count: number | null
          title: string
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          content?: string | null
          created_at?: string | null
          id?: string
          image_url?: string | null
          likes_count?: number | null
          title: string
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          content?: string | null
          created_at?: string | null
          id?: string
          image_url?: string | null
          likes_count?: number | null
          title?: string
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "posts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_stats"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "posts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          display_name: string | null
          email: string | null
          id: string
          updated_at: string | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          display_name?: string | null
          email?: string | null
          id: string
          updated_at?: string | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          display_name?: string | null
          email?: string | null
          id?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      push_tokens: {
        Row: {
          created_at: string | null
          device_type: string | null
          id: string
          token: string
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          device_type?: string | null
          id?: string
          token: string
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          device_type?: string | null
          id?: string
          token?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "push_tokens_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_stats"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "push_tokens_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          billing_cycle: string | null
          category_id: string | null
          cost: number
          created_at: string | null
          id: string
          name: string
          next_billing_date: string | null
          proof_url: string | null
          status: string | null
          user_id: string
        }
        Insert: {
          billing_cycle?: string | null
          category_id?: string | null
          cost: number
          created_at?: string | null
          id?: string
          name: string
          next_billing_date?: string | null
          proof_url?: string | null
          status?: string | null
          user_id: string
        }
        Update: {
          billing_cycle?: string | null
          category_id?: string | null
          cost?: number
          created_at?: string | null
          id?: string
          name?: string
          next_billing_date?: string | null
          proof_url?: string | null
          status?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      tasks: {
        Row: {
          category_id: string | null
          created_at: string | null
          description: string | null
          due_date: string | null
          id: string
          priority: string | null
          proof_url: string | null
          status: string | null
          title: string
          user_id: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          priority?: string | null
          proof_url?: string | null
          status?: string | null
          title: string
          user_id: string
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          priority?: string | null
          proof_url?: string | null
          status?: string | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tasks_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      travel_logs: {
        Row: {
          budget: number | null
          category_id: string | null
          created_at: string | null
          destination: string
          end_date: string | null
          id: string
          notes: string | null
          proof_url: string | null
          spent: number | null
          start_date: string
          user_id: string
        }
        Insert: {
          budget?: number | null
          category_id?: string | null
          created_at?: string | null
          destination: string
          end_date?: string | null
          id?: string
          notes?: string | null
          proof_url?: string | null
          spent?: number | null
          start_date: string
          user_id: string
        }
        Update: {
          budget?: number | null
          category_id?: string | null
          created_at?: string | null
          destination?: string
          end_date?: string | null
          id?: string
          notes?: string | null
          proof_url?: string | null
          spent?: number | null
          start_date?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "travel_logs_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      users: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          display_name: string | null
          email: string
          firebase_uid: string
          id: string
          updated_at: string | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          display_name?: string | null
          email: string
          firebase_uid: string
          id?: string
          updated_at?: string | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          display_name?: string | null
          email?: string
          firebase_uid?: string
          id?: string
          updated_at?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      user_stats: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          display_name: string | null
          email: string | null
          firebase_uid: string | null
          id: string | null
          total_likes_received: number | null
          total_notifications: number | null
          total_posts: number | null
        }
        Relationships: []
      }
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
