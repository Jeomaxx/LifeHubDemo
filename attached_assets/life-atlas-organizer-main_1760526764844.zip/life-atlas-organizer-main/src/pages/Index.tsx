import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Plus, Upload, Calendar, BookOpen, Target, Heart, DollarSign, CheckSquare, Package, CreditCard, Receipt, TrendingUp, GraduationCap, Zap, Gamepad2, Film, Gift, Link, FileText, Briefcase, Calendar as CalendarIcon, Users, Plane, LogOut, User } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import FinanceModule from '@/components/modules/FinanceModule';
import TaskModule from '@/components/modules/TaskModule';
import GoalModule from '@/components/modules/GoalModule';
import HealthModule from '@/components/modules/HealthModule';
import JournalModule from '@/components/modules/JournalModule';
import AssetModule from '@/components/modules/AssetModule';
import SubscriptionModule from '@/components/modules/SubscriptionModule';
import BillModule from '@/components/modules/BillModule';
import InvestmentModule from '@/components/modules/InvestmentModule';
import LearningModule from '@/components/modules/LearningModule';
import HabitsModule from '@/components/modules/HabitsModule';
import HobbiesModule from '@/components/modules/HobbiesModule';
import MediaModule from '@/components/modules/MediaModule';
import BirthdaysModule from '@/components/modules/BirthdaysModule';

const Index = () => {
  const [activeModule, setActiveModule] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const { user, signOut, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const modules = [
    {
      id: 'finance',
      name: 'Finance Management',
      description: 'Track income, expenses, and budgets with proof uploads',
      icon: DollarSign,
      color: 'bg-green-500',
      entries: 12,
      component: FinanceModule
    },
    {
      id: 'assets',
      name: 'Asset Management',
      description: 'Track valuable possessions and their worth',
      icon: Package,
      color: 'bg-indigo-500',
      entries: 8,
      component: AssetModule
    },
    {
      id: 'subscriptions',
      name: 'Subscription Tracker',
      description: 'Monitor recurring services and renewals',
      icon: CreditCard,
      color: 'bg-pink-500',
      entries: 6,
      component: SubscriptionModule
    },
    {
      id: 'bills',
      name: 'Bill Tracker',
      description: 'Track utility bills and payment status',
      icon: Receipt,
      color: 'bg-orange-500',
      entries: 9,
      component: BillModule
    },
    {
      id: 'tasks',
      name: 'Task & Project Management',
      description: 'Organize tasks and projects with priority tracking',
      icon: CheckSquare,
      color: 'bg-blue-500',
      entries: 8,
      component: TaskModule
    },
    {
      id: 'goals',
      name: 'Goal Setting',
      description: 'Set and track SMART goals with milestones',
      icon: Target,
      color: 'bg-purple-500',
      entries: 5,
      component: GoalModule
    },
    {
      id: 'investments',
      name: 'Investment Tracker',
      description: 'Track buy/sell transactions and performance',
      icon: TrendingUp,
      color: 'bg-emerald-500',
      entries: 4,
      component: InvestmentModule
    },
    {
      id: 'learning',
      name: 'Learning Resources',
      description: 'Track books, courses, and educational content',
      icon: GraduationCap,
      color: 'bg-cyan-500',
      entries: 7,
      component: LearningModule
    },
    {
      id: 'journal',
      name: 'Journaling',
      description: 'Daily notes with mood tracking and insights',
      icon: BookOpen,
      color: 'bg-amber-500',
      entries: 22,
      component: JournalModule
    },
    {
      id: 'health',
      name: 'Health & Fitness',
      description: 'Monitor workouts, nutrition, and wellness',
      icon: Heart,
      color: 'bg-red-500',
      entries: 15,
      component: HealthModule
    },
    {
      id: 'habits',
      name: 'Habits Tracker',
      description: 'Build and maintain daily/weekly routines',
      icon: Zap,
      color: 'bg-yellow-500',
      entries: 10,
      component: HabitsModule
    },
    {
      id: 'hobbies',
      name: 'Hobbies Tracker',
      description: 'Record time spent on hobbies and activities',
      icon: Gamepad2,
      color: 'bg-violet-500',
      entries: 5,
      component: HobbiesModule
    },
    {
      id: 'media',
      name: 'Films & TV Tracker',
      description: 'Track movies and shows with ratings',
      icon: Film,
      color: 'bg-rose-500',
      entries: 18,
      component: MediaModule
    },
    {
      id: 'birthdays',
      name: 'Birthday & Gift Tracker',
      description: 'Remember birthdays and gift ideas',
      icon: Gift,
      color: 'bg-teal-500',
      entries: 12,
      component: BirthdaysModule
    },
    {
      id: 'links',
      name: 'Important Links',
      description: 'Save and categorize useful links',
      icon: Link,
      color: 'bg-lime-500',
      entries: 25,
      component: () => <div>Important Links Module - Coming Soon</div>
    },
    {
      id: 'contracts',
      name: 'Contract Manager',
      description: 'Track contracts and expiration dates',
      icon: FileText,
      color: 'bg-slate-500',
      entries: 3,
      component: () => <div>Contract Manager Module - Coming Soon</div>
    },
    {
      id: 'jobs',
      name: 'Job Application Tracker',
      description: 'Monitor job applications and interviews',
      icon: Briefcase,
      color: 'bg-stone-500',
      entries: 7,
      component: () => <div>Job Application Tracker Module - Coming Soon</div>
    },
    {
      id: 'events',
      name: 'Event Planner',
      description: 'Plan and organize events with budgets',
      icon: CalendarIcon,
      color: 'bg-fuchsia-500',
      entries: 4,
      component: () => <div>Event Planner Module - Coming Soon</div>
    },
    {
      id: 'contacts',
      name: 'Contact & Network Manager',
      description: 'Manage personal and professional contacts',
      icon: Users,
      color: 'bg-sky-500',
      entries: 45,
      component: () => <div>Contact Manager Module - Coming Soon</div>
    },
    {
      id: 'travel',
      name: 'Travel Log',
      description: 'Record trips and travel experiences',
      icon: Plane,
      color: 'bg-emerald-600',
      entries: 8,
      component: () => <div>Travel Log Module - Coming Soon</div>
    }
  ];

  const filteredModules = modules.filter(module =>
    module.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    module.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (activeModule) {
    const module = modules.find(m => m.id === activeModule);
    if (module) {
      const ModuleComponent = module.component;
      return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Button 
                  variant="outline" 
                  onClick={() => setActiveModule(null)}
                  className="hover:bg-slate-100"
                >
                  ← Back to Dashboard
                </Button>
                <div className="flex items-center gap-2">
                  <module.icon className="h-6 w-6 text-slate-600" />
                  <h1 className="text-2xl font-bold text-slate-800">{module.name}</h1>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-600">Welcome, {user.email}</span>
                <Button variant="ghost" size="sm" onClick={() => signOut()}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            </div>
            <ModuleComponent />
          </div>
        </div>
      );
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <User className="h-6 w-6 text-slate-600" />
              <span className="text-slate-600">Welcome, {user.email}</span>
            </div>
            <Button variant="ghost" onClick={() => signOut()}>
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
          <h1 className="text-4xl font-bold text-slate-800 mb-3">
            Life Atlas Organizer
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Your comprehensive personal management hub with 20+ modules to track every aspect of your life
          </p>
        </div>

        {/* Search and Stats */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Search modules..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white border-slate-200 focus:border-blue-400"
            />
          </div>
          <div className="flex gap-4">
            <Badge variant="secondary" className="px-4 py-2 text-sm">
              Total Entries: {modules.reduce((sum, module) => sum + module.entries, 0)}
            </Badge>
            <Badge variant="secondary" className="px-4 py-2 text-sm">
              Active Modules: {modules.length}
            </Badge>
          </div>
        </div>

        {/* Module Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredModules.map((module) => (
            <Card 
              key={module.id} 
              className="hover:shadow-lg transition-shadow duration-200 cursor-pointer border-slate-200 bg-white/80 backdrop-blur-sm"
              onClick={() => setActiveModule(module.id)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className={`p-3 rounded-lg ${module.color} bg-opacity-10`}>
                    <module.icon className={`h-6 w-6 ${module.color.replace('bg-', 'text-')}`} />
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {module.entries} entries
                  </Badge>
                </div>
                <CardTitle className="text-lg text-slate-800">{module.name}</CardTitle>
                <CardDescription className="text-sm text-slate-600">
                  {module.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div className="flex gap-2">
                    <Badge variant="secondary" className="text-xs">
                      <Upload className="w-3 h-3 mr-1" />
                      Proof Support
                    </Badge>
                  </div>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    Open →
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Stats Section */}
        <div className="mt-12">
          <h2 className="text-2xl font-semibold text-slate-800 mb-6">Today's Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <DollarSign className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Today's Expenses</p>
                    <p className="text-xl font-semibold text-slate-800">$127.50</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <CheckSquare className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Tasks Completed</p>
                    <p className="text-xl font-semibold text-slate-800">6/12</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <Target className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Goals on Track</p>
                    <p className="text-xl font-semibold text-slate-800">4/5</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-100 rounded-lg">
                    <Heart className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-600">Workout Streak</p>
                    <p className="text-xl font-semibold text-slate-800">7 days</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
